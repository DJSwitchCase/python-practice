import setuptools

setuptools.setup(name="myPackageSetup",
                 version="0.0.1",
                 author="Igor",
                 author_email="LighterST@yandex.ru",
                 packages=setuptools.find_packages(),
                 description="This is a test package")
