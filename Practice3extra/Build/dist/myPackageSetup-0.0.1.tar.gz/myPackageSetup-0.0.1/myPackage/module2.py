def test2():
    print("test2")